<?php
// Local IIS configuration. This ignored PHP file returns data but emits no
// response when executed by PHP. Keep it outside the web root in production.
return [
    'pii_encryption_key' => '7d60ff8a65f9936236531ae7f5d346c9152d98c087e05ad7738a3fb23a111418',
    'lookup_secret_key' => 'c1fe84c37d1812ceb972cc38c6b362aa40b2164669197ec6c9740aa50d4566be',
    'decoder_admin_username' => 'cerritos-admin',
    'decoder_admin_password' => 'cb56c37efb4740ce2d584af33a6c28d62c3a',
    'google_spreadsheet_id' => '1-19mTWjH2vl-eeW6z-zlfjxSkv1DbW5hQjQkzzdpZXU',
    'debug_submission_errors' => false,
    // TLS certificate validation is enabled after the IIS CA bundle test passed.
    'verify_google_tls' => true,
];
