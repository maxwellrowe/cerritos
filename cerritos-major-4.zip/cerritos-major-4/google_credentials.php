<?php
// Service-account credentials. Keep this ignored file outside the IIS web root
// in production; it returns data and emits no response when requested via PHP.
return json_decode(substr(file_get_contents(__FILE__), __COMPILER_HALT_OFFSET__), true, 512, JSON_THROW_ON_ERROR);
__halt_compiler();
{
  "type": "service_account",
  "project_id": "major-selector-504723",
  "private_key_id": "f6c9de9703eb8ba6b597120975a0f29749811bb4",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDrFgG7zdS7aHhR\nwa5WV0oz9nmfGQojVkxh9hs5vMyL/PPhtoqVJBmqE9/ChPJUCNnvd6FE2GHZynMl\nVzNcl49S3T2MxorIeYbYeeJtCrX3jt0H8E8e4kjBiaK5C7QqyqXRrsMLwPMsApQY\nmN3W6y+diLfdBh830muu746nuql9CZAGzu4x7vLURm9MdUoIRspiDcnxTnDzYNyl\nDrLZ4fEbNNZweSkSty4FV91nS/VxZKScOuuH42OPBSFFyLJ8vrRgrfMabX16MWnz\nMGKV2I/p/jztoqyn4xzDyUlz8SmtOhzlsG/S3h522/ZcFeEQMGjmnVfAZGOHd4nE\n4bvs1BlXAgMBAAECggEAD/WRAMMy729JFJSXW/fJRLWbwRZalVaM94a7h22bqnjU\nKt0RE5njsiOiQg4NED5l/F2wBMDDawOIhWu7kJjraAudjsdSizr3OA5iNdcPZ/+t\nxEjnBI8F5tM/Fdyt12Y/E19ckP/OCMCHqRNrozHMX2xbvkH/PMA1gw0/r0xUdQ8s\nhVxcPekeSj9PpBf+MZFCM//2q9xRaXhR/7hB/+qmre/WPvJflZmOXGvbrEHZItxA\noDpM4gnoS/WpH1wEYty+VEBb4cwNJBUHt/QC6SG5qob2B1znzVPtMMKTT2q68uAB\nJWoy8Z+WO95pOYfWc+wHVi4yGrORe/GR6sHbPwdbCQKBgQD4ZJ5ojJNrA+hbwxBD\nylDd0Zzpt314Dvlrsod0qruUi2uefSULXUCt/5kc8D5FxQrsRKVOsuajgTvAkD5N\nyeMEim8eQtDjguSMSfhKdbcIinQ+dovNsoY7HjUciGFIhWD/tmnI/2BnsE93bTI9\nE85X01euoY4NWrYA872r6EkLXwKBgQDySQ/DuLF0XhOF09xPi07sJv7bWFd8A7E7\nYCZT31Pr9/dsh/+lXDvUPqC3ZtN3yM9uDcDx9ywWCwnnYq5dVDoDIbcZWgAmEsV5\nj2NHpp3ThKxyER8INmdx1hwacFgYwwG1AgS1L8/R4pXYrmUlbH6aYEUY/UahyX8x\ngqcHTp0tCQKBgBEBmpLf5QvzpYn6zfdGN8koG80ooe+BXvRPsdR8CAHAleqw+MNR\nbCc9k7cWf7z5I6lPfd3og7/4DiY9+fYLd36NF9SDkJezE4DDY7t9Wb289P590U6R\nBX2wsMQ2VirH7v8y9wUq7ufKe3ZaxJDH9V2v+5XaO8aQSlvAVGEbszyTAoGAEF+p\nphN8Qp38+cVYlTOX8NOt04sD1oi1WIrl7DMii8blPLtwJm+2R2C4IczcK7MxeYGK\ncY+/tfmnALElkX8YsI99vUPc0LXiDJYJIpV7AwlrUgYgL8Dlesb6fTrsaTf8jIwH\nX2tMwyVp9QvMIBxV7f7ljIvJUzO32dO3kAHbE2kCgYEAqPJraza1FXB2tbUr4FvB\nxvqB/u1yTHEDfeh0ECHTR1ikxK/qi4rGMooPo0DhbUFjj7u3CD73GErD9vXPr/WQ\npp8uG0HO5VY/pe6WSRwZpdws6J9cqbd9XZKcvDOQ1t8rKJv7pVpd2C9Uq/vX6Q4A\n7szGY1WwPRBIKgd7FogES+Q=\n-----END PRIVATE KEY-----\n",
  "client_email": "major-selector@major-selector-504723.iam.gserviceaccount.com",
  "client_id": "111325337674109398734",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/major-selector%40major-selector-504723.iam.gserviceaccount.com",
  "universe_domain": "googleapis.com"
}
